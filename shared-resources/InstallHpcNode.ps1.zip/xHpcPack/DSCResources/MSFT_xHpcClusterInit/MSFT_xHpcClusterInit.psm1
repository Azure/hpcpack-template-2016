#
# xHpcPackInstall: DSC resource to install HPC Pack.
#

function Get-TargetResource
{
    [OutputType([System.Collections.Hashtable])]
    param
    (
        # Currently only topology "Enterprise" is supported in Azure
        [Parameter(Mandatory=$true)]
        [ValidateSet("Enterprise")]
        [String] $Topology,

        [parameter(Mandatory = $true)]
        [System.Management.Automation.PSCredential] $SetupCredential,

        [Parameter(Mandatory=$false)]
        [Boolean] $UseLinuxHttps = $false,

        [Parameter(Mandatory=$false)]
        [String] $AzureStorageConnString = "",

        [Parameter(Mandatory=$false)]
        [String] $CNSize = "",

        [Parameter(Mandatory=$false)]
        [String] $SubscriptionId = "",

        [Parameter(Mandatory=$false)]
        [String] $Location = "",
    
        [Parameter(Mandatory=$false)]
        [String] $VNet = "",

        [Parameter(Mandatory=$false)]
        [String] $Subnet = "",

        [Parameter(Mandatory=$false)]
        [String] $ResourceGroup = "",

        [Parameter(Mandatory=$false)]
        [String] $AutoGSApplicationId = "",

        [Parameter(Mandatory=$false)]
        [String] $AutoGSTenantId = "",

        [Parameter(Mandatory=$false)]
        [String] $AutoGSThumbprint = ""
    )

    return $PSBoundParameters
}

function Set-TargetResource
{
    param
    (
        # Currently only topology "Enterprise" is supported in Azure
        [Parameter(Mandatory=$true)]
        [ValidateSet("Enterprise")]
        [String] $Topology,

        [parameter(Mandatory = $true)]
        [System.Management.Automation.PSCredential] $SetupCredential,

        [Parameter(Mandatory=$false)]
        [Boolean] $UseLinuxHttps = $false,

        [Parameter(Mandatory=$false)]
        [String] $AzureStorageConnString = "",

        [Parameter(Mandatory=$false)]
        [String] $CNSize = "",

        [Parameter(Mandatory=$false)]
        [String] $SubscriptionId = "",

        [Parameter(Mandatory=$false)]
        [String] $Location = "",
    
        [Parameter(Mandatory=$false)]
        [String] $VNet = "",

        [Parameter(Mandatory=$false)]
        [String] $Subnet = "",

        [Parameter(Mandatory=$false)]
        [String] $ResourceGroup = "",

        [Parameter(Mandatory=$false)]
        [String] $AutoGSApplicationId = "",

        [Parameter(Mandatory=$false)]
        [String] $AutoGSTenantId = "",

        [Parameter(Mandatory=$false)]
        [String] $AutoGSThumbprint = ""
    )

    LoadRequiredModules
    $retry = 0
    while($true)
    {
        try
        {
            Connect-ServiceFabricCluster -ErrorAction Stop
            Get-ServiceFabricApplicationHealth -ApplicationName 'fabric:/HpcApplication' -ErrorAction Stop
            break
        }
        catch
        {
            if($retry -ge 5)
            {
                throw "Service Fabric Cluster or Hpc Fabric application is not ready: $_"
            }
            else
            {
                Write-Verbose "Service Fabric Cluster or Hpc Fabric application is not ready, wait for 10 seconds ..."
                Start-Sleep -Seconds 10
            }
        }
    }
    
    $desiredProperties = @{}
    if($SubscriptionId)
    {
        $desiredProperties['SubscriptionId'] = $SubscriptionId
    }
    if($Location)
    {
        $desiredProperties['Location'] = $Location
    }
    if($VNet)
    {
        $desiredProperties['VNet'] = $VNet
    }
    if($Subnet)
    {
        $desiredProperties['Subnet'] = $Subnet
    }
    if($ResourceGroup)
    {
        $desiredProperties['ResourceGroup'] = $ResourceGroup
    }
    if($AutoGSApplicationId)
    {
        $desiredProperties['ApplicationId'] = $AutoGSApplicationId
    }
    if($AutoGSTenantId)
    {
        $desiredProperties['TenantId'] = $AutoGSTenantId
    }
    if($AutoGSThumbprint)
    {
        $desiredProperties['Thumbprint'] = $AutoGSThumbprint
    }
    if($UseLinuxHttps)
    {
        $desiredProperties['LinuxHttps'] = 1
    }
    else
    {
        $desiredProperties['LinuxHttps'] = 0
    }
    
    $needRestartScheduler = $false
    $curProperties = Get-HpcReliableProperty.ps1
    foreach($pName in $desiredProperties.Keys)
    {
        $curValue = $curProperties | ?{$_.Name -eq $pName} | select -First(1) | %{$_.Value}
        if($desiredProperties[$pName] -ne $curValue)
        {
            Write-Verbose "Setting Property $pName to $($desiredProperties[$pName])"
            Set-HpcReliableProperty.ps1 -PropertyName $pName -PropertyValue $desiredProperties[$pName]
            if($pName -eq 'LinuxHttps')
            {
                $needRestartScheduler = $true
            }
        }
    }

    while($true)
    {
        try
        {
            Get-HpcClusterOverview -ErrorAction Stop
            break
        }
        catch
        {
            if($retry -ge 15)
            {
                throw "Cannot connect to HPC cluster: $_"
            }
            else
            {
                Write-Verbose "Cannot connect to HPC cluster, wait for 10 seconds ..."
                Start-Sleep -Seconds 10
            }
        }
    }

    $topo = Get-HpcNetworkTopology -ErrorAction SilentlyContinue
    if($topo -ne $Topology)
    {
        $startTime = Get-Date
        Write-Verbose "Set HPC Network topology"
        $nics = @(Get-WmiObject win32_networkadapterconfiguration -filter "IPEnabled='true' AND DHCPEnabled='true'")
        if ($nics.Count -ne 1)
        {
            throw "Cannot find a suitable network adapter for enterprise topology"
        }

        Set-HpcNetwork -Topology $Topology -Enterprise $nics.Description -EnterpriseFirewall $true -ErrorAction SilentlyContinue
    }


    Write-Verbose "Set HPC Setup User Credential"
    Set-HpcClusterProperty -InstallCredential $SetupCredential

    $nodenaming = 'AzureVMCN-%0000%'
    Write-Verbose "Node naming series set to $nodenaming"
    Set-HpcClusterProperty -NodeNamingSeries $nodenaming

    Write-Verbose "Set AzureStorageConnectionString"
    Set-HpcClusterProperty -AzureStorageConnectionString $AzureStorageConnString


    # If the VMSize of the compute nodes is A8/A9, set the MPI net mask.
    if($CNSize -match "(A8|A9)$")
    {
        $mpiNetMask = "172.16.0.0/255.255.0.0"
        ## Wait for the completion of the "Updating cluster configuration" operation after setting network topology,
        ## because in the operation, the CCP_MPI_NETMASK may be reset.
        if($topo -ne $Topology)
        {
            $waitLoop = 0
            while ($null -eq (Get-HpcOperation -StartTime $startTime -State Committed | ?{$_.Name -eq "Updating cluster configuration"}))
            {
                if($waitLoop++ -ge 10)
                {
                    break
                }

                Start-Sleep -Seconds 10
            }
        }

        Set-HpcClusterProperty -Environment "CCP_MPI_NETMASK=$mpiNetMask"  | Out-Null
        Write-Verbose "Set cluster environment CCP_MPI_NETMASK to $mpiNetMask"
    }

    if($needRestartScheduler)
    {
        $opId = [Guid]::NewGuid()
        Start-ServiceFabricPartitionRestart -OperationId $opId -RestartPartitionMode AllReplicasOrInstances -ServiceName fabric:/HpcApplication/SchedulerStatefulService
    }
}

function Test-TargetResource
{
    param
    (
        # Currently only topology "Enterprise" is supported in Azure
        [Parameter(Mandatory=$true)]
        [ValidateSet("Enterprise")]
        [String] $Topology,

        [parameter(Mandatory = $true)]
        [System.Management.Automation.PSCredential] $SetupCredential,

        [Parameter(Mandatory=$false)]
        [Boolean] $UseLinuxHttps = $false,

        [Parameter(Mandatory=$false)]
        [String] $AzureStorageConnString = "",

        [Parameter(Mandatory=$false)]
        [String] $CNSize = "",

        [Parameter(Mandatory=$false)]
        [String] $SubscriptionId = "",

        [Parameter(Mandatory=$false)]
        [String] $Location = "",
    
        [Parameter(Mandatory=$false)]
        [String] $VNet = "",

        [Parameter(Mandatory=$false)]
        [String] $Subnet = "",

        [Parameter(Mandatory=$false)]
        [String] $ResourceGroup = "",

        [Parameter(Mandatory=$false)]
        [String] $AutoGSApplicationId = "",

        [Parameter(Mandatory=$false)]
        [String] $AutoGSTenantId = "",

        [Parameter(Mandatory=$false)]
        [String] $AutoGSThumbprint = ""
    )
    
    try
    {
        LoadRequiredModules
        Connect-ServiceFabricCluster -ErrorAction Stop | Out-Null
        $hpcApp = Get-ServiceFabricApplication -ApplicationName 'fabric:/HpcApplication' -ErrorAction SilentlyContinue
        if($null -eq $hpcApp)
        {
            Write-Verbose "HPC Fabric application not ready"
            return $false
        }

        $topo = Get-HpcNetworkTopology -ErrorAction SilentlyContinue
        if($topo -ne $Topology)
        {
            Write-Verbose "Network topology not set"
            return $false
        }

        $hpccred = Get-HpcClusterProperty -InstallCredential -ErrorAction SilentlyContinue
        if($null -eq $hpccred)
        {
            Write-Verbose "InstallCredential need to be set"
            return $false
        }

        $curStorageConnString = Get-HpcClusterProperty -Name AzureStorageConnectionString -Parameter -ErrorAction SilentlyContinue
        if($AzureStorageConnString -and ($AzureStorageConnString -ne $curStorageConnString))
        {
            Write-Verbose "AzureStorageConnectionString need to be set"
            return $false
        }

        $desiredProperties = @{}
        if($SubscriptionId)
        {
            $desiredProperties['SubscriptionId'] = $SubscriptionId
        }
        if($Location)
        {
            $desiredProperties['Location'] = $Location
        }
        if($VNet)
        {
            $desiredProperties['VNet'] = $VNet
        }
        if($Subnet)
        {
            $desiredProperties['Subnet'] = $Subnet
        }
        if($ResourceGroup)
        {
            $desiredProperties['ResourceGroup'] = $ResourceGroup
        }
        if($AutoGSApplicationId)
        {
            $desiredProperties['ApplicationId'] = $AutoGSApplicationId
        }
        if($AutoGSTenantId)
        {
            $desiredProperties['TenantId'] = $AutoGSTenantId
        }
        if($AutoGSThumbprint)
        {
            $desiredProperties['Thumbprint'] = $AutoGSThumbprint
        }
        if($UseLinuxHttps)
        {
            $desiredProperties['LinuxHttps'] = 1
        }
        else
        {
            $desiredProperties['LinuxHttps'] = 0
        }

        $curProperties = Get-HpcReliableProperty.ps1
        foreach($pName in $desiredProperties.Keys)
        {
            $curValue = $curProperties | ?{$_.Name -eq $pName} | select -First(1) | %{$_.Value}
            if($desiredProperties[$pName] -ne $curValue)
            {
                Write-Verbose "Property $pName need to be set"
                return $false
            }
        }

        return $true
    }
    catch
    {
        return $false
    }
}

function LoadRequiredModules
{
    $hpcSnapIn = Get-PSSnapin -Name Microsoft.HPC -ErrorAction SilentlyContinue
    if($null -eq $hpcSnapIn)
    {
        Add-PSSnapin Microsoft.HPC | Out-Null
    }

    $fabricModule = Get-Module -Name ServiceFabric -ErrorAction SilentlyContinue
    if($null -eq $fabricModule)
    {
        Import-Module ServiceFabric -ErrorAction Stop | Out-Null
        $curEnvPaths = $env:Path -split ';'
        $machineEnvPath = [System.Environment]::GetEnvironmentVariable('Path', 'Machine') -split ';'
        $env:Path = ($curEnvPaths + $machineEnvPath | select -Unique) -join ';'
    }
}

Export-ModuleMember -Function *-TargetResource
