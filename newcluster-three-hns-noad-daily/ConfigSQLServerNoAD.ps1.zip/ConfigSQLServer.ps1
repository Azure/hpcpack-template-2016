﻿configuration ConfigSQLServer 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$LoginCredential,

        [String]$SQLInstanceName = "MSSQLSERVER",

        [Int]$RetryCount=20,

        [Int]$RetryIntervalSec=30
    ) 
    
    Import-DscResource -ModuleName xStorage, xSQLServer, xNetworking
    if($SQLInstanceName -eq "MSSQLSERVER")
    {
        $sqlService = "MSSQLSERVER"
    }
    else
    {
        $sqlService = "MSSQL`$$SQLInstanceName"
    }

    Node localhost
    {
        LocalConfigurationManager
        {
            ActionAfterReboot = 'ContinueConfiguration'
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }

        cSQLServerLoginMode SetMixedLoginMode
        {
            SQLInstanceName = $SQLInstanceName
            LoginMode = "Mixed"
        }

        xWaitforDisk Disk2
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        xDisk ADDataDisk
        {
            DiskNumber = 2
            DriveLetter = "F"
            FSLabel = 'ADData'
            DependsOn = "[xWaitforDisk]Disk2"
        }

        xFirewall SQLServerTCPIn
        {
            Name = "sqlservice-tcp-in"
            DisplayName = "Allow SQL Server TCP In"
            Ensure = "Present"
            Action = "Allow"
            Direction = "Inbound"
            Protocol = "TCP"
            Service = $sqlService
        }

        xSQLServerLogin AddSQLServerLogin
        {
            Ensure = "Present"
            Name = $LoginCredential.UserName
            LoginType = "SqlLogin"
            LoginCredential = $LoginCredential
            SQLInstanceName = $SQLInstanceName
            DependsOn = "[xDisk]ADDataDisk", "[cSQLServerLoginMode]SetMixedLoginMode"
        }

        xSQLServerRoleMembership AddSysadminForLogin
        {
            Ensure = "Present"
            RoleName = "sysadmin"
            Login = $LoginCredential.UserName
            SQLInstanceName = $SQLInstanceName
            DependsOn = "[xSQLServerLogin]AddSQLServerLogin"
        }

        File HPCDataFolder
        {
            Type = 'Directory'
            Ensure = "Present"
            DestinationPath = 'F:\HPCData'
            DependsOn = "[xDisk]ADDataDisk"
        }

        cSQLServerDatabase HPCManagementDB
        {
            Database = 'HPCManagement'
            Ensure = 'Present'
            SQLInstanceName = $SQLInstanceName
            Location = 'F:\HPCData'
            DataFileSizeInMB = 2048
            DataFileGrowthPercent = 50
            LogFileSizeInMB = 256
            LogFileGrowthPercent = 10
            DependsOn = "[File]HPCDataFolder","[xSQLServerRoleMembership]AddSysadminForLogin"
        }

        cSQLServerDatabase HPCSchedulerDB
        {
            Database = 'HPCScheduler'
            Ensure = 'Present'
            SQLInstanceName = $SQLInstanceName
            Location = 'F:\HPCData'
            DataFileSizeInMB = 2048
            DataFileGrowthPercent = 50
            LogFileSizeInMB = 256
            LogFileGrowthPercent = 50
            DependsOn = "[File]HPCDataFolder","[xSQLServerRoleMembership]AddSysadminForLogin"
        }

        cSQLServerDatabase HPCReportingDB
        {
            Database = 'HPCReporting'
            Ensure = 'Present'
            SQLInstanceName = $SQLInstanceName
            Location = 'F:\HPCData'
            DataFileSizeInMB = 2048
            DataFileGrowthPercent = 50
            LogFileSizeInMB = 256
            LogFileGrowthPercent = 10
            DependsOn = "[File]HPCDataFolder","[xSQLServerRoleMembership]AddSysadminForLogin"
        }

        cSQLServerDatabase HPCDiagnosticsDB
        {
            Database = 'HPCDiagnostics'
            Ensure = 'Present'
            SQLInstanceName = $SQLInstanceName
            Location = 'F:\HPCData'
            DataFileSizeInMB = 256
            DataFileGrowthPercent = 50
            LogFileSizeInMB = 64
            LogFileGrowthPercent = 10
            DependsOn = "[File]HPCDataFolder","[xSQLServerRoleMembership]AddSysadminForLogin"
        }

        cSQLServerDatabase HPCMonitoringDB
        {
            Database = 'HPCMonitoring'
            Ensure = 'Present'
            SQLInstanceName = $SQLInstanceName
            Location = 'F:\HPCData'
            DataFileSizeInMB = 512
            DataFileGrowthPercent = 50
            LogFileSizeInMB = 64
            LogFileGrowthPercent = 10
            DependsOn = "[File]HPCDataFolder","[xSQLServerRoleMembership]AddSysadminForLogin"
        }
    }
} 

