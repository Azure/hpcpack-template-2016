﻿configuration ConfigSQLServer 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [String]$HeadNodeList,

        [String]$SQLInstanceName = "MSSQLSERVER",

        [Int]$RetryCount=20,

        [Int]$RetryIntervalSec=30
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory, xStorage, xSQLServer, xComputerManagement, xNetworking
    $DomainNetBiosName = $DomainName.Split('.')[0]
    $ADUserName = "${DomainNetBiosName}\$($Admincreds.UserName)"
    $HeadNodes = @($HeadNodeList -split ',')
    $HNAccounts = @($HeadNodes | %{"${DomainNetBiosName}\$_$"})
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ($ADUserName, $Admincreds.Password)
    if($SQLInstanceName -eq "MSSQLSERVER")
    {
        $sqlService = "MSSQLSERVER"
    }
    else
    {
        $sqlService = "MSSQL`$$SQLInstanceName"
    }

    Node localhost
    {
        LocalConfigurationManager
        {
            ActionAfterReboot = 'ContinueConfiguration'
            ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $true
        }

        xWaitforDisk Disk2
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        xDisk ADDataDisk
        {
            DiskNumber = 2
            DriveLetter = "F"
            FSLabel = 'ADData'
        }

        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        }

        xWaitForADDomain DscForestWait 
        { 
            DomainName = $DomainName 
            DomainUserCredential= $DomainCreds
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec 
            DependsOn = "[WindowsFeature]ADPS"      
        }

        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[xWaitForADDomain]DscForestWait" 
        }

        xFirewall SQLServerTCPIn
        {
            Name = "sqlservice-tcp-in"
            DisplayName = "Allow SQL Server TCP In"
            Ensure = "Present"
            Action = "Allow"
            Direction = "Inbound"
            Protocol = "TCP"
            Service = $sqlService
            DependsOn = "[xComputer]DomainJoin"
        }

        Group AddADUserToLocalAdminGroup
        {
            GroupName = 'Administrators'   
            Ensure = 'Present'             
            MembersToInclude= $ADUserName
            Credential = $DomainCreds    
            DependsOn = "[xComputer]DomainJoin"
        }

        xSQLServerLogin AddSQLServerLoginForADUser
        {
            Ensure = "Present"
            Name = $ADUserName
            LoginType = "WindowsUser"
            SQLInstanceName = $SQLInstanceName
            DependsOn = "[xComputer]DomainJoin"
        }

        xSQLServerRoleMembership AddSysadminForADUser
        {
            Ensure = "Present"
            RoleName = "sysadmin"
            Login = $ADUserName
            SQLInstanceName = $SQLInstanceName
            DependsOn = "[xSQLServerLogin]AddSQLServerLoginForADUser"
        }

        File HPCDataFolder
        {
            Type = 'Directory'
            Ensure = "Present"
            DestinationPath = 'F:\HPCData'
            DependsOn = "[xComputer]DomainJoin"
        }

        cSQLServerDatabase HPCManagementDB
        {
            Database = 'HPCManagement'
            Ensure = 'Present'
            SQLInstanceName = $SQLInstanceName
            Location = 'F:\HPCData'
            DataFileSizeInMB = 2048
            DataFileGrowthPercent = 50
            LogFileSizeInMB = 256
            LogFileGrowthPercent = 10
            DependsOn = "[File]HPCDataFolder"
        }

        cSQLServerDatabase HPCSchedulerDB
        {
            Database = 'HPCScheduler'
            Ensure = 'Present'
            SQLInstanceName = $SQLInstanceName
            Location = 'F:\HPCData'
            DataFileSizeInMB = 2048
            DataFileGrowthPercent = 50
            LogFileSizeInMB = 256
            LogFileGrowthPercent = 50
            DependsOn = "[File]HPCDataFolder"
        }

        cSQLServerDatabase HPCReportingDB
        {
            Database = 'HPCReporting'
            Ensure = 'Present'
            SQLInstanceName = $SQLInstanceName
            Location = 'F:\HPCData'
            DataFileSizeInMB = 2048
            DataFileGrowthPercent = 50
            LogFileSizeInMB = 256
            LogFileGrowthPercent = 10
            DependsOn = "[File]HPCDataFolder"
        }

        cSQLServerDatabase HPCDiagnosticsDB
        {
            Database = 'HPCDiagnostics'
            Ensure = 'Present'
            SQLInstanceName = $SQLInstanceName
            Location = 'F:\HPCData'
            DataFileSizeInMB = 256
            DataFileGrowthPercent = 50
            LogFileSizeInMB = 64
            LogFileGrowthPercent = 10
            DependsOn = "[File]HPCDataFolder"
        }

        cSQLServerDatabase HPCMonitoringDB
        {
            Database = 'HPCMonitoring'
            Ensure = 'Present'
            SQLInstanceName = $SQLInstanceName
            Location = 'F:\HPCData'
            DataFileSizeInMB = 512
            DataFileGrowthPercent = 50
            LogFileSizeInMB = 64
            LogFileGrowthPercent = 10
            DependsOn = "[File]HPCDataFolder"
        }

        foreach($hn in $HeadNodes)
        {
            $HNAccount = "${DomainNetBiosName}\$hn$"
            cWaitForADComputer "WaitForHeadNode$hn"
            {
                ComputerName = $hn
                PsDscRunAsCredential = $DomainCreds
                DependsOn = "[cSQLServerDatabase]HPCManagementDB","[cSQLServerDatabase]HPCSchedulerDB","[cSQLServerDatabase]HPCReportingDB","[cSQLServerDatabase]HPCDiagnosticsDB","[cSQLServerDatabase]HPCMonitoringDB"
            }

            xSQLServerLogin "AddSQLServerLoginFor$hn"
            {
                Ensure = "Present"
                Name = $HNAccount
                LoginType = "WindowsUser"
                SQLInstanceName = $SQLInstanceName
                DependsOn = "[cWaitForADComputer]WaitForHeadNode$hn"
            }

            xSQLServerDatabaseRole "HPCManagementDBOwnerFor$hn"
            {
                Ensure = "Present"
                Name = $HNAccount
                Role = "db_owner"
                Database = 'HPCManagement'
                SQLInstanceName = $SQLInstanceName
                DependsOn = "[xSQLServerLogin]AddSQLServerLoginFor$hn"
            }

            xSQLServerDatabaseRole "HPCSchedulerDBOwnerFor$hn"
            {
                Ensure = "Present"
                Name = $HNAccount
                Role = "db_owner"
                Database = 'HPCScheduler'
                SQLInstanceName = $SQLInstanceName
                DependsOn = "[xSQLServerLogin]AddSQLServerLoginFor$hn"
            }

            xSQLServerDatabaseRole "HPCReportingDBOwnerFor$hn"
            {
                Ensure = "Present"
                Name = $HNAccount
                Role = "db_owner"
                Database = 'HPCReporting'
                SQLInstanceName = $SQLInstanceName
                DependsOn = "[xSQLServerLogin]AddSQLServerLoginFor$hn"
            }

            xSQLServerDatabaseRole "HPCDiagnosticsDBOwnerFor$hn"
            {
                Ensure = "Present"
                Name = $HNAccount
                Role = "db_owner"
                Database = 'HPCDiagnostics'
                SQLInstanceName = $SQLInstanceName
                DependsOn = "[xSQLServerLogin]AddSQLServerLoginFor$hn"
            }

            xSQLServerDatabaseRole "HPCMonitoringDBOwnerFor$hn"
            {
                Ensure = "Present"
                Name = $HNAccount
                Role = "db_owner"
                Database = 'HPCMonitoring'
                SQLInstanceName = $SQLInstanceName
                DependsOn = "[xSQLServerLogin]AddSQLServerLoginFor$hn"
            }
        }
   }
} 

